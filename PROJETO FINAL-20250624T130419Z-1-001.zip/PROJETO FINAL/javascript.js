document.getElementById("quiz-form").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const nome = document.getElementById("nome").value.trim();
    if (!nome) {
      alert("Digite seu nome antes de enviar.");
      return;
    }
  
    const respostasCorretas = {
      q1: "Júpiter",
      q2: "Marte",
      q3: "Saturno",
      q4: "Mercúrio",
      q5: "Netuno"
    };
  
    let pontuacao = 0;
  
    for (let i = 1; i <= 5; i++) {
      const resposta = document.querySelector(`input[name="q${i}"]:checked`);
      if (resposta && resposta.value === respostasCorretas[`q${i}`]) {
        pontuacao++;
      }
    }
  
    document.getElementById("resultado").textContent = `${nome}, você acertou ${pontuacao} de 5 perguntas.`;
  });
  